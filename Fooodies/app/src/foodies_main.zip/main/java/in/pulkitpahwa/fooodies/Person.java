package in.pulkitpahwa.fooodies;

/**
 * Created by pulkit on 21/4/15.
 */

public class Person {

    private String name;
    private String country;
    private String twitter;

    public void setName(String name)
    {
        this.name = name;
    }

    public void setCountry(String country)
    {
        this.country = country;
    }

    public void setTwitter(String twitter)
    {
        this.twitter = twitter;
    }

    public String getName()
    {
        return this.name;
    }
    public String getCountry()
    {
        return this.country;
    }
    public String getTwitter()
    {
        return this.twitter;
    }
//getters & setters....

}