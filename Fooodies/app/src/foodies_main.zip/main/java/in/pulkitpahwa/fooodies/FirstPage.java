package in.pulkitpahwa.fooodies;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ProgressBar;
import android.os.Handler;





public class FirstPage extends ActionBarActivity {

    private ProgressBar progressBar;
    private Handler handler= new Handler();
    private int progressStatus = 0;
    private String number;
    private RequestAppID obj;
    private CreateAppID db = new CreateAppID(this);



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_first_page);

        progressBar = (ProgressBar)findViewById(R.id.progressBar);
        progressBar.getProgressDrawable().setColorFilter(Color.parseColor("#6a1815"), PorterDuff.Mode.SRC_IN);

        Log.w("myapp","01");
        progressBar.setProgress(0);

        progressBar.setVisibility(View.VISIBLE);
        Log.w("myapp","02");

        new Thread(new Runnable() {
            public void run() {
                    try {
                        //check if app_id exist. if not, request for app_id.
                        Log.w("myapp","entered thread1");
                        int count = db.getIDsCount();
                        if(count == 0) {
                            try {
                                Log.w("myapp","0");
                                TelephonyManager tm = (TelephonyManager) getSystemService(TELEPHONY_SERVICE);
                                number = tm.getLine1Number();
                                Log.w("myapp", number);

                            } catch (Exception e) {
                                number = "000";
                                Log.w("myapp","1");
                            }
                            Log.w("myapp","2");
                            obj = new RequestAppID();
                            obj.fetchJSON(number);
                            Log.w("myapp","3");
                            while (obj.parsingComplete) ;
                            db.addAppID(obj.getId());
                            Log.w("myapp", "appid " + obj.getId().toString());
                            progressStatus = 100;
                            Log.w("myapp","5");
                            if(progressStatus == 100) {
                                homepage();
                            }

                        }

                    } catch (Exception e) {
                        e.printStackTrace();
                        Log.w("myapp","4");
                    }
            }
        }).start();



        new Thread(new Runnable() {
                public void run() {
                    Log.w("myapp","Entered thread 2");
                    while (progressStatus < 90) {
                        progressStatus += 1;
                        Log.w("myapp","5");
                        if(progressStatus == 100) {
                            Log.w("myapp",Integer.toString(progressStatus));
                            progressBar.setVisibility(View.INVISIBLE);
                            Log.w("myapp","8");
                        }
                        // Update the progress bar and display the
                        //current value in the text view
                        handler.post(new Runnable() {
                            public void run() {
                                progressBar.setProgress(progressStatus);
                                Log.w("myapp","555555555555555555555555");
                                Log.w("myapp",Integer.toString(progressStatus));
                            }
                        });
                        try {
                            // Sleep for 200 milliseconds.
                            //Just to display the progress slowly
                            Log.w("myapp","6");
                            Thread.sleep(400);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                            Log.w("myapp","7");
                        }
                    }
                }
            }).start();




    }

    public void homepage()
    {
        Intent home = new Intent(this, HomePage.class);
        startActivity(home);
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_first_page, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
