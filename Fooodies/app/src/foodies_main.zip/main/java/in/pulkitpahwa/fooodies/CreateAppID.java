package in.pulkitpahwa.fooodies;

/**
 * Created by pulkit on 24/4/15.
 */


import java.util.ArrayList;
import java.util.List;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.widget.Toast;


public class CreateAppID extends SQLiteOpenHelper {

    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "app_manager";
    private static final String TABLE_APP_ID = "app_id";
    private static final String App_id= "id";

    public CreateAppID(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // Creating Tables
    @Override
    public void onCreate(SQLiteDatabase db) {
        Log.w("myapp", "dbhandler on create");
        try {
            SQLiteDatabase checkDB = null;
            db = SQLiteDatabase.openDatabase(TABLE_APP_ID, null,
                    SQLiteDatabase.OPEN_READWRITE);
            Log.w("myapp","db exist");
        }
        catch (SQLiteException e) {
            String CREATE_App_Id_TABLE = "CREATE TABLE " + TABLE_APP_ID + "("
                    + App_id + " INTEGER PRIMARY KEY AUTOINCREMENT);";
            db.execSQL(CREATE_App_Id_TABLE);
            Log.w("myapp","db created");
        }
        Log.w("myapp", "dbhandler 1");
    }

    // Upgrading database
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop older table if existed
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_APP_ID);

        // Create tables again
        onCreate(db);
    }

    /**
     * All CRUD(Create, Read, Update, Delete) Operations
     */

    // Adding new contact
    void addAppID(String fetched_app_id) {
        String selectQuery = "SELECT  * FROM " + TABLE_APP_ID;
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);
        if(cursor.getCount() == 0)
        {
            ContentValues values = new ContentValues();
            values.put(App_id, fetched_app_id );
            db.insert(TABLE_APP_ID, null, values);
        }
        else{

        }
    }

    // Getting single contact
    public int getAppID() {

        Log.w("myapp", "dbhandler 9");
        String selectQuery = "SELECT  * FROM " + TABLE_APP_ID;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);
        if (cursor.getCount()== 1)
        {
            return cursor.getInt(0);
        }
        else{
            cursor.moveToFirst();
            return cursor.getInt(0);
        }
    }

    // Getting contacts Count
    public int getIDsCount() {
        String countQuery = "SELECT  * FROM " + TABLE_APP_ID;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(countQuery, null);
        // return count
        return cursor.getCount();
    }



}