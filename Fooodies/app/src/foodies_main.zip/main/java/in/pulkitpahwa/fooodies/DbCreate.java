package in.pulkitpahwa.fooodies;

/**
 * Created by pulkit on 25/4/15.
 */
public class DbCreate {
    //private DatabaseHandler db = new DatabaseHandler(this);


}
